# Nandi OS Version 2 UI

This package contains a ready-to-run Streamlit UI that visually matches the green neon Nandi OS dashboard mockup.

## Files
- app.py
- assets/nandi_bull_logo.png
- assets/nandi_mountain.png
- assets/reference_mockup.png

## Install / Run
Open PowerShell:

```powershell
cd C:\Nandi
streamlit run app.py
```

Open:

```text
http://localhost:8501
```

or:

```text
http://nandi.ai.local:8501
```

## How to use
Copy `app.py` into your existing `C:\Nandi\app.py` and copy the `assets` folder into `C:\Nandi\assets`.
